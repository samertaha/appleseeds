export const func1 = () => {
  return "Func1";
};

export const func2 = () => {
  return "Func2";
};

export const func3 = () => {
  return "Func3";
};
